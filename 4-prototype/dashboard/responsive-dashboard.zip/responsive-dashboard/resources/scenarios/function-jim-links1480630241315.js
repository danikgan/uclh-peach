(function(window, undefined) {

  var jimLinks = {
    "80c3cedb-4e48-4602-bd61-96aa60736d9b" : {
    },
    "237d2074-94c7-47c6-a764-4c01c53072c5" : {
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
    }    
  }

  window.jimLinks = jimLinks;
})(window);